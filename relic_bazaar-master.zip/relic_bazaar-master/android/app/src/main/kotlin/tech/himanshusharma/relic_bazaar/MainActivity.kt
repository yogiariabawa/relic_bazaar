package tech.himanshusharma.relicbazaar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
