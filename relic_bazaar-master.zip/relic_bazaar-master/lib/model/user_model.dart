class UserModel {
  UserModel({
    this.name,
    this.email,
    this.imageUrl,
    this.phoneNumber,
    this.uid,
  });

  final String? name, email, imageUrl, uid, phoneNumber;
}
