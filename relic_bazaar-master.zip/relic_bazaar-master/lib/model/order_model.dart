class Order {
  Order({
    this.title,
    this.image,
    this.ordered,
    this.status,
    this.delivered,
  });

  String? title;
  String? image;
  String? ordered;
  String? status;
  bool? delivered;
}
