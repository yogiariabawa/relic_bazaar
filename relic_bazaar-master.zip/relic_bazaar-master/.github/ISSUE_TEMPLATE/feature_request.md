---
name: Feature Request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--- Provide a general summary of the feature in the Title above -->
# Feature Request ✨
<!--- Provide an expanded summary of the feature -->

## Use Case
<!--- Tell us what feature we should support and what should happen -->

## Possible Solution
<!--- Not obligatory, but suggest an implementation -->

## Context
<!--- How has this issue affected you? What are you trying to accomplish? -->
<!--- Providing context helps us come up with a solution that is most useful in the real world -->

## Detailed Description
<!--- Provide a detailed description of the change or addition you are proposing -->