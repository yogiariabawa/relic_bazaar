---
name: Custom Issue
about: For miscellaneous, such as questions, discussions, etc.
title: ''
labels: ''
assignees: ''

---

<!--- Provide a general summary of the issue in the Title above -->
# Discussion 🗣
<!--- Provide an expanded summary of the issue -->

## Context
<!--- Providing context helps us come to the discussion informed -->

## Detailed Description
<!--- Provide any further details -->